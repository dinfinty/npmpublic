# Firefly Client Library - Python
Python client library to interact with firefly api gateway to place orders on firefly exchange and to interact with on-chain firefly contracts.

### How to use
- Install packages using `pip install -r requirements.in`
